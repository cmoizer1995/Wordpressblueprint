<?php
function hwep_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'helloworldmentopro'),
    ));
}
add_action('after_setup_theme', 'hwep_setup');

function hwep_widgets_init() {
    register_sidebar(array(
        'name'          => __('Main Sidebar', 'helloworldmentopro'),
        'id'            => 'sidebar-1',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'hwep_widgets_init');
