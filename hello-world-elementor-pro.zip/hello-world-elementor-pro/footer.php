<footer style="text-align:center;padding:20px;background:#ddd;margin-top:40px;">
    <p>&copy; <?php echo date('Y'); ?> Connor Moizer</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
