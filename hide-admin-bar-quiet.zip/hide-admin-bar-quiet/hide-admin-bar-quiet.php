<?php
/**
 * Plugin Name: Hide Admin Bar (Quiet)
 * Description: Hides the WordPress admin bar on the frontend for all users.
 * Version: 1.0
 * Author: Connor Moizer
 */

if (!defined('ABSPATH')) {
    exit;
}

add_filter('show_admin_bar', '__return_false');
